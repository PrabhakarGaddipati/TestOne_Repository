package Test.Automation;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import readers.ExcelReader;


public class JiraAPITests {
	
/*	
	@Test
	public void AddComment() {
		ExcelReader ereader = new ExcelReader(System.getProperty("user.dir")+"\\src\\main\\resources\\config\\APIData.xlsx");
		String testCasename = ereader.getCellData("TestData", "TestCase", 3);
		String host = ereader.getCellData("TestData", "Host", 3);
		String path = ereader.getCellData("TestData", "Path", 3);
		String authorization = ereader.getCellData("TestData", "Authorization", 3);
		String payload = ereader.getCellData("TestData", "Body", 3);
        try{
        	
        	System.out.println("TestCase: "+ testCasename);
            Response res = RestAssured.given()
            		.header("Authorization", authorization)
            		.contentType(ContentType.JSON)
            		.body(payload).when().
            		post(host+path);
            System.out.println(" Output Response :: "+res.andReturn().asString()); //Return Output JSON Response
            Assert.assertEquals(res.getStatusCode(), 201);
            long timeInMS = res.time();
            long timeInS = res.timeIn(TimeUnit.SECONDS);
            System.out.println(timeInMS);
            System.out.println(timeInS);
            
        }
        catch(Exception e)
        {
            System.out.println( e.getMessage());
        }
    }
		*/
	

	@Test
	public void getProjects() {
		ExcelReader ereader = new ExcelReader(System.getProperty("user.dir")+"\\src\\main\\resources\\config\\APIData.xlsx");
		String testCasename = ereader.getCellData("TestData", "TestCase", 2);
		String host = ereader.getCellData("TestData", "Host", 2);
		String path = ereader.getCellData("TestData", "Path", 2);
		String authorization = ereader.getCellData("TestData", "Authorization", 2);
		String payload = ereader.getCellData("TestData", "Body", 2);
        try{
        	
        	System.out.println("TestCase: "+ testCasename);
            Response res = RestAssured.given()
            		.header("Authorization", authorization)
            		.contentType(ContentType.JSON)
            		.body(payload).when().
            		get(host+path);
       	 	int code =res.getStatusCode();
       	 	System.out.println("Status code :"+code);
            Assert.assertEquals(res.getStatusCode(), 200);
            long timeInMS = res.time();
            long timeInS = res.timeIn(TimeUnit.SECONDS);
            System.out.println(timeInMS);
             System.out.println(timeInS);
           

        	
        }
        catch(Exception e)
        {
            System.out.println( e.getMessage());
        }
    }
		
/*	
	@Test
	public void updateTheComment() {
		ExcelReader ereader = new ExcelReader(System.getProperty("user.dir")+"\\src\\main\\resources\\config\\APIData.xlsx");
		String testCasename = ereader.getCellData("TestData", "TestCase", 4);
		String host = ereader.getCellData("TestData", "Host", 4);
		String path = ereader.getCellData("TestData", "Path", 4);
		String authorization = ereader.getCellData("TestData", "Authorization", 4);
		String payload = ereader.getCellData("TestData", "Body", 4);
        try{
        	
        	System.out.println("TestCase: "+ testCasename);
            Response res = RestAssured.given()
            		.header("Authorization", authorization)
            		.contentType(ContentType.JSON)
            		.body(payload).when().
            		put(host+path);
            System.out.println(" Output Response :: "+res.andReturn().asString()); //Return Output JSON Response
            Assert.assertEquals(res.getStatusCode(), 200);
            long timeInMS = res.time();
            long timeInS = res.timeIn(TimeUnit.SECONDS);
            System.out.println(timeInMS);
            System.out.println(timeInS);
            
        }
        catch(Exception e)
        {
            System.out.println( e.getMessage());
        }
    }
	
	@Test
	public void DelteTheComment() {
		ExcelReader ereader = new ExcelReader(System.getProperty("user.dir")+"\\src\\main\\resources\\config\\APIData.xlsx");
		String testCasename = ereader.getCellData("TestData", "TestCase", 5);
		String host = ereader.getCellData("TestData", "Host", 5);
		String path = ereader.getCellData("TestData", "Path", 5);
		String authorization = ereader.getCellData("TestData", "Authorization", 5);
		String payload = ereader.getCellData("TestData", "Body", 5);
        try{
        	
        	System.out.println("TestCase: "+ testCasename);
            Response res = RestAssured.given()
            		.header("Authorization", authorization)
            		.contentType(ContentType.JSON)
            		.body(payload).when().
            		delete(host+path);
            System.out.println(" Output Response :: "+res.andReturn().asString()); //Return Output JSON Response
            Assert.assertEquals(res.getStatusCode(), 204);
            long timeInMS = res.time();
            long timeInS = res.timeIn(TimeUnit.SECONDS);
            System.out.println(timeInMS);
            System.out.println(timeInS);
            
        }
        catch(Exception e)
        {
            System.out.println( e.getMessage());
        }
    }
	
	
	
	
	
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
	
	
	
	
	
	
	


